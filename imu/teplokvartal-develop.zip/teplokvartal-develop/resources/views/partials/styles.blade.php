<link href="/css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="/css/slick.css" rel="stylesheet" type="text/css">
<link href="/css/slick-theme.css" rel="stylesheet" type="text/css">
<link href="/css/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css">
<link href="/css/magnific-popup.css" rel="stylesheet" type="text/css">
<link href="/css/app.css" rel="stylesheet">
