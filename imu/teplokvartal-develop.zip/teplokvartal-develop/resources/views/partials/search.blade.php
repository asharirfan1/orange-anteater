<form action="{{ $action }}" class="search-form">
    <span style="display: inline-block; position: relative">
            <input type="text" class="search_input" name="queryString" placeholder="{{ $placeholder }}">
            <button type="submit" class="search-button"><i class="fa fa-search" aria-hidden="true"></i></button>
        </span>
</form>
