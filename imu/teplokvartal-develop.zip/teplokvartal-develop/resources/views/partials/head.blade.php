<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="yandex-verification" content="1bfcadf2b728d01e" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Теплоквартал</title>
<link rel="shortcut icon" type="image/png" href="/images/logo2.png"/>
@include ('partials.styles')
@include ('partials.livereload')
