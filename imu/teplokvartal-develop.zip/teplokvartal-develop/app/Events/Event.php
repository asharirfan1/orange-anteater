<?php

namespace Teplokvartal\Events;

abstract class Event
{
    //
}
